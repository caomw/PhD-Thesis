This is copy of src/java/api directory from xmlpull-api-v1 CVS
for more details see: http://www.xmlpull.org
