/**
 * Copyright (C) 2006  Eider Moore
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package org.eiderman.util;

import java.util.ArrayList;
import java.util.Collection;

/**
 * This is a densely packed list that acts like it has infinate size.
 * Adding a value beyond the max size will cause it to fill in the blanks
 * and requesting a value beyond the max size will return null.  If you
 * are adding data that is sparse, this will be very, very inefficient.
 * @author eider
 *
 * @param <T>
 */
public class DenseInfinateList<T> extends ArrayList<T>
{   
   public DenseInfinateList()
   {
      super();
   }

   public DenseInfinateList(Collection<? extends T> c)
   {
      super(c);
   }

   public DenseInfinateList(int initialCapacity)
   {
      super(initialCapacity);
   }

   private void fillBlanks(int index)
   {
      while (index > size())
      {
         super.add(null);
      }
   }
   
   @Override
   public void add(int index, T element)
   {
      fillBlanks(index);
      super.add(index, element);
   }
   
   @Override
   public T get(int index)
   {
      if (index >= size())
         return null;
      return super.get(index);
   }
   
   @Override
   public boolean addAll(int index, Collection<? extends T> c)
   {
      fillBlanks(index);
      return super.addAll(index, c);
   }
   
   @Override
   public T remove(int index)
   {
      if (index >= size())
         return null;
      return super.remove(index);
   }
   
   @Override
   public T set(int index, T element)
   {
      if (index >= size())
         fillBlanks(index + 1);
      return super.set(index, element);
   }
}
