/**
 * Copyright (C) 2006  Eider Moore
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package org.eiderman.util;

import java.util.AbstractMap;
import java.util.AbstractSet;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Set;

public class PropertyMap extends AbstractMap<String, Object>
{
   PropertyFactory factory;
   
   int mod = 0;
   int size = 0;
   DenseInfinateList<Object> values;
   DenseInfinateList<Property<?>> keys;
   
   @Override   
   public Set<Entry<String, Object>> entrySet()
   {
      return new Entries();
   }

   @Override
   public boolean containsKey(Object key)
   {
      Property prop;
      if (key instanceof String)
      {
         prop = factory.get((String) key);
         if (prop == null)
            return false;
      }
      else if (key instanceof Property<?>)
      {
         prop = (Property) key;
         if (!factory.contains(prop))
            return false;
      }
      else
      {
         return false;
      }
      return values.get(prop.ordinal()) != null;
   }
   
   @Override
   public boolean containsValue(Object value)
   {
      if (value == null)
         return false;
      return values.contains(value);
   }
   
   @Override
   public boolean isEmpty()
   {
      return size == 0;
   }
   
   @Override
   public int size()
   {
      return size;
   }
   
    @Override
   public Object put(String key, Object value)
   {
       if (value == null)
          throw new NullPointerException();
       Property<?> prop = factory.getAndCreateIfAbsent(key, value);
       assert prop.getPropertyClass().isAssignableFrom(value.getClass());
       int index = prop.ordinal();
       Object result = values.set(index, value);
       if (result == null)
          size++;
       mod++;
       return result;
   }
   
    @Override
   public Object remove(Object key)
   {
       Property prop;
       if (key instanceof String)
       {
          prop = factory.get((String) key);
          if (prop == null)
             return null;
       }
       else if (key instanceof Property<?>)
       {
          prop = (Property) key;
          if (!factory.contains(prop))
             return null;
       }
       else
       {
          return null;
       }
       Object result = values.set(prop.ordinal(), null);
       if (result != null)
          size--;
       mod++;       
       return result;
   }
    
    // checked when it came in
   @SuppressWarnings("unchecked")
   public <T> T put(Property<T> prop, T value)
   {
      if (value == null)
         throw new NullPointerException();
      if (!factory.contains(prop))
         throw new IllegalArgumentException("Incompatible property!");
      assert prop.getPropertyClass().isAssignableFrom(value.getClass());
      int index = prop.ordinal();
      T result = (T) values.set(index, value);
      if (result == null)
         size++;
      mod++;
      return result;
   }
    
    @Override
   public Object get(Object key)
   {
       Property prop;
       if (key instanceof String)
       {
          prop = factory.get((String) key);
          if (prop == null)
             return null;
       }
       else if (key instanceof Property<?>)
       {
          prop = (Property) key;
          if (!factory.contains(prop))
             return null;
       }
       else
       {
          return null;
       }
       return values.get(prop.ordinal());
   }
    
    private class Entries extends AbstractSet<Entry<String, Object>>
    {
       @Override
       public int size()
       {
          return size;
       }
       
       @Override
       public Iterator<Entry<String, Object>> iterator()
       {
          return new Iterator<Entry<String, Object>>()
         {
             int myMod = mod;
             int index = -1;
             
            public void remove()
            {
               if (mod != myMod)
                  throw new ConcurrentModificationException();
               PropertyMap.this.remove(factory.get(index));
            }
         
            public Entry<String, Object> next()
            {
               if (mod != myMod)
                  throw new ConcurrentModificationException();
               index = findNext(index + 1);
               if (index < 0)
                  throw new NoSuchElementException();
               return new Entry<String, Object>(){
               
                  int i = index;
                  public Object setValue(Object value)
                  {
                     if (!factory.get(i).getPropertyClass().isAssignableFrom(value.getClass()))
                        throw new IllegalArgumentException("Not the right class!");
                     return values.set(i, value);
                  }
               
                  public Object getValue()
                  {
                     return values.get(i);
                  }
               
                  public String getKey()
                  {
                     return factory.get(i).toString();
                  }
               };
            }
         
            private int findNext(int from)
            {
               while (from < values.size())
               {
                  if ((index != from) && values.get(from) != null)
                     return from;
                  else
                     from++;
               }
               return -1;
            }
            
            public boolean hasNext()
            {
               if (mod != myMod)
                  throw new ConcurrentModificationException();
               return findNext(index + 1) >= 0;
            }         
         };
       }
    }
}
